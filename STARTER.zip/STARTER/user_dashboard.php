
    <?php 
session_start();
include "db.php";

// Fetch books with borrow status
$search = "";
$whereClause = "";
if (isset($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    $whereClause = "WHERE b.title LIKE '%$search%' OR b.author LIKE '%$search%'";
}

$booksQuery = "SELECT b.*, COALESCE(bb.user_id, '') AS borrowed_by 
               FROM books b 
               LEFT JOIN borrowed_books bb ON b.id = bb.book_id 
               $whereClause";
$booksResult = mysqli_query($conn, $booksQuery) or die("Query failed: " . mysqli_error($conn));

// Process Borrow and Return Actions
if (isset($_GET['action'], $_GET['book_id'])) {
    $action = $_GET['action'];
    $book_id = intval($_GET['book_id']);
    $user_id = $_SESSION['user_id'] ?? 0;

    if ($action === 'borrow') {
        $checkQuery = "SELECT * FROM borrowed_books WHERE book_id = '$book_id'";
        $checkResult = mysqli_query($conn, $checkQuery);

        if (mysqli_num_rows($checkResult) == 0) {
            $borrowQuery = "INSERT INTO borrowed_books (book_id, user_id, due_date) 
                            VALUES ('$book_id', '$user_id', DATE_ADD(NOW(), INTERVAL 7 DAY))";
            mysqli_query($conn, $borrowQuery) ? 
                alertRedirect("Book borrowed successfully!", "user_dashboard.php") :
                alert("Error borrowing book!");
        } else {
            alertRedirect("Book is already borrowed!", "user_dashboard.php");
        }
    } elseif ($action === 'return') {
        $returnQuery = "DELETE FROM borrowed_books WHERE book_id = '$book_id' AND user_id = '$user_id'";
        mysqli_query($conn, $returnQuery) ? 
            alertRedirect("Book returned successfully!", "user_dashboard.php") :
            alert("Error returning book!");
    }
}


function alert($message) {
    echo "<script>alert('$message');</script>";
}
function alertRedirect($message, $redirect) {
    echo "<script>alert('$message'); window.location='$redirect';</script>";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Library</title>
    <style>
        /* Global Styles */
        body {
            font-family: Arial, sans-serif;
            background-color: whitesmoke;
            margin: 0;
            padding: 0;
            color: #333;
        }
        a {
            text-decoration: none;
        }
        /* Header */
        .header {
            background-color: rgb(248, 95, 6);
            color: white;
            padding: 15px;
            text-align: center;
        }
        /* Container */
        .container {
            width: 90%;
            margin: 20px auto;
        }
        /* Search Bar */
        .search-bar {
            text-align: center;
            margin-top: 180px;
        }
        .search-bar input[type="text"] {
            width: 40%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        .search-bar button {
            padding: 10px 20px;
            background-color: black;
            color: white;
            border: none;
            border-radius: 5px;
            margin-left: 10px;
            cursor: pointer;
            transition: 0.3s;
        }
        .search-bar button:hover {
            background-color: white;
            color: black;
            border: 2px solid black;
        }
        /* Books Grid */
        .books-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .book-card {
            margin: 30px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 10px;
            padding: 15px;
            box-shadow: 0px 4px 8px rgba(0,0,0,0.1);
            transition: transform 0.3s;
        }
        .book-card:hover {
            transform: translateY(-5px);
        }
        .book-card img {
            width: 100%;
            height: auto;
            border-radius: 5px;
        }
        .book-card h3 {
            color: rgb(248, 95, 6);
            margin-top: 10px;
        }
        .book-card p {
            font-size: 14px;
            line-height: 1.6;
        }
        .actions {
            margin-top: 10px;
        }
        .actions a {
            display: inline-block;
            padding: 8px 12px;
            margin: 5px 3px 0 0;
            border-radius: 5px;
            font-size: 14px;
            font-weight: bold;
            text-align: center;
            transition: all 0.3s ease;
        }
        /* Borrow/Return Button */
        .borrow-btn {
            background-color: rgb(248, 95, 6);
            color: white;
            border: 2px solid rgb(248, 95, 6);
        }
        .borrow-btn:hover {
            background-color: white;
            color: rgb(248, 95, 6);
            border: 2px solid rgb(248, 95, 6);
        }
        .return-btn {
            background-color: black;
            color: white;
            border: 2px solid black;
        }
        .return-btn:hover {
            background-color: white;
            color: black;
            border: 2px solid black;
        }
        /* Download/Read Button */
        .download-btn, .read-btn {
            background-color: black;
            color: white;
            border: 2px solid black;
        }
        .download-btn:hover, .read-btn:hover {
            background-color: white;
            color: black;
            border: 2px solid black;
        }
        /* Dashboard Navigation */
        .dashboard-nav {
  display: flex;
  justify-content: end;
  margin-right: 40px;
  padding: 10px 0;
  gap: 10px;
}
.dashboard-nav a {
  padding: 10px 20px;
  background-color: black;
  color: white;
  border-radius: 5px;
  font-weight: bold;
  transition: 0.3s;
}
.dashboard-nav a:hover {
  background-color: white;
  color: black;
  border: 2px solid black;
}


        header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      background-color: rgb(248, 95, 6);
      color: white;
      padding: 15px 20px;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 1000;
    }


    .status{
        color: green;
        font-weight: bold;
    }

    </style>
</head>
<body>
    <header class="header">
        <!-- <h1>User Dashboard</h1> -->
        <nav class="dashboard-nav">
            <a href="homepage.php">Log Out</a>
            <a href="checks.php">Checks</a>
        </nav>
    </header>
    
    <div class="search-bar">
        <form action="user_dashboard.php" method="GET">
            <input type="text" name="search" placeholder="Search for a book..." value="<?php echo htmlspecialchars($search); ?>">
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="container">
        <h1>Available Books</h1>
        <div class="books-grid">
            <?php while ($book = mysqli_fetch_assoc($booksResult)) : ?>
                <div class="book-card">
                    <?php if (!empty($book['cover_image'])) : ?>
                        <img src="<?php echo htmlspecialchars($book['cover_image']); ?>" alt="Book Cover">
                    <?php endif; ?>
                    <h2><?php echo htmlspecialchars($book['title']); ?></h2>
                    <p><strong>Author:</strong> <?php echo htmlspecialchars($book['author']); ?></p>
                    <p><strong>Category:</strong> <?php echo htmlspecialchars($book['genre']); ?></p>
                    <p class="status" style="color: <?php echo !empty($book['borrowed_by']) ? 'red' : 'rgb(248, 95, 6)'; ?>;">
    Status: <?php echo !empty($book['borrowed_by']) ? "Borrowed" : "Available"; ?>
</p>

                    <div class="actions">
    <?php if (!empty($book['pdf_file'])) : ?>
        <a href="<?php echo htmlspecialchars($book['pdf_file']); ?>" target="_blank" class="btn read-btn">Read</a>
    <?php endif; ?>

    <?php if (empty($book['borrowed_by'])) : ?>
        <a href="user_dashboard.php?action=borrow&book_id=<?php echo $book['id']; ?>" class="btn borrow-btn">Borrow</a>
    <?php else : ?>
        <a href="user_dashboard.php?action=return&book_id=<?php echo $book['id']; ?>" class="btn return-btn">Return</a>
    <?php endif; ?>
</div>

                </div>
            <?php endwhile; ?>
        </div>
    </div>
</body>
</html>
